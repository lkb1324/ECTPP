from torch import nn
import torch
from models import HGNN_conv1,HGNN_conv2,MLP # 超图卷积层
import torch.nn.functional as F # 提供了一堆神经网络的激活函数和功能函数


class HGNN(nn.Module):
    def __init__(self, in_ch, n_class, conv_hid,mlp_hid,dropout = 0.5):
        super(HGNN, self).__init__()
        self.dropout = dropout
        self.hgc1 = HGNN_conv1(in_ch,conv_hid) # 定义两个具体的卷积层，分别命名为hgc1和hgc2
        self.hgc2 = HGNN_conv2(conv_hid+5,conv_hid) #136*128
        self.MLP = MLP(conv_hid+103,mlp_hid,n_class) # 128->512->1
        

    def forward(self, x, DV2_H, W, invDE_HT_DV2,edge_fts,G,index_features): # 定义数据流动的方向，输入数据两个，x和G，是根据HGNN_conv确定的
        x = F.relu(self.hgc1(x, DV2_H, W, invDE_HT_DV2,edge_fts)) # HGNN_conv(in_ch, n_hid)
        x = F.dropout(x,self.dropout)
        x = F.relu(self.hgc2(x, G)) # HGNN_conv(n_hid, n_class)



        x = torch.cat([x, index_features],dim= 1,out=None)
        x = self.MLP(x)
        
        return x # n*1
